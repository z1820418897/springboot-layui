package com.gcrobot.application.util;

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

@Data
public class LayuiMenu implements Serializable {
    private Integer id;
    private String title;
    private String icon;
    private boolean spread;
    private String href;
    private List children;
}
