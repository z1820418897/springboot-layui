package com.gcrobot.application.bean;

import com.gcrobot.application.util.LayuiMenu;
import lombok.Data;

import java.io.Serializable;

@Data
public class Menu implements Serializable {
    private Integer menuId;
    private String menuTitle;
    private String menuHref;
//    private String menuIcon;
//    private Integer menuSpread;
    private Integer pid;
    private Integer appId;

    public LayuiMenu formatLayuiMenu(){

        LayuiMenu layuiMenu = new LayuiMenu();

        layuiMenu.setHref(menuHref);
//        layuiMenu.setIcon(menuIcon);
//        layuiMenu.setSpread(menuSpread==0?false:true);
        layuiMenu.setIcon("");
        layuiMenu.setSpread(false);
        layuiMenu.setTitle(menuTitle);
        layuiMenu.setId(menuId);

        return layuiMenu;
    }
}
