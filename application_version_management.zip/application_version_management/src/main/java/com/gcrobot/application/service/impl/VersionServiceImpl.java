package com.gcrobot.application.service.impl;

import com.gcrobot.application.bean.Application;
import com.gcrobot.application.bean.Version;
import com.gcrobot.application.mapper.VersionMapper;
import com.gcrobot.application.service.VersionService;
import com.gcrobot.application.util.PageHelp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class VersionServiceImpl implements VersionService {

    @Autowired
    private VersionMapper versionMapper;

    @Override
    public Version findVersion(Integer appId) {
        return versionMapper.findVersion(appId);
    }

    @Override
    public List<Version> findVersionByMenuId(Integer menuId) {
        return versionMapper.findVersionByMenuId(menuId);
    }

    @Override
    public Integer findVersionCount() {
        return versionMapper.findVersionCount();
    }

    @Override
    public List<Version> findVersionByMenuId(PageHelp page, Integer menuId) {

        page.setStart((page.getPage()-1)*page.getLimit());
        page.setEnd(page.getLimit());

        List<Version> data=versionMapper.findVersionByMenuIdLimit(page.getStart(),page.getEnd(),menuId);

        return data;
    }


    @Override
    public Application findAppByMenuId(Integer menuId) {

        return versionMapper.findAppByMenuId(menuId);
    }


    @Override
    public Integer findVersionCode(Integer versionCode,Integer menuId) {

        return versionMapper.findVersionCode(versionCode,menuId);
    }



    @Override
    public Integer saveVersion(Version version, Integer menuId) {

        int versionVip=version.getVersionVip().equals("是")?1:0;
        version.setUploadTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));

        return versionMapper.saveVersion(versionVip,version,menuId);
    }

    @Override
    public Integer updateVersion(Version version) {

        int versionVip=version.getVersionVip().equals("是")?1:0;


        return versionMapper.updateVersion(versionVip,version);
    }

    @Override
    public List<Version> findVersionPath(String ids) {

        ArrayList<Integer> list = new ArrayList<>();
        String[] split = ids.split(",");
        for (String str:split) {
            list.add(Integer.parseInt(str));
        }

        return versionMapper.findVersionPath(list);
    }

    @Override
    public Integer deleteVersion(String ids) {

        ArrayList<Integer> list = new ArrayList<>();
        String[] split = ids.split(",");
        for (String str:split) {
            list.add(Integer.parseInt(str));
        }

        return versionMapper.deleteVersion(list);
    }


}
