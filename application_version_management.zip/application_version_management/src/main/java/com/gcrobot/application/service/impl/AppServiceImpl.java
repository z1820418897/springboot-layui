package com.gcrobot.application.service.impl;

import com.gcrobot.application.bean.Application;
import com.gcrobot.application.bean.Menu;
import com.gcrobot.application.mapper.AppMapper;
import com.gcrobot.application.service.AppService;
import com.gcrobot.application.util.FileHelps;
import com.gcrobot.application.util.PageHelp;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class AppServiceImpl implements AppService {

    @Autowired
    private AppMapper appMapper;

    @Value("${gc.file-path}")
    private String gcFilePath;

    @Override
    public Integer findAppCount() {
        return appMapper.findAppCount();
    }

    @Override
    public List<Application> findAppAll(PageHelp page) {

        page.setStart((page.getPage()-1)*page.getLimit());
        page.setEnd(page.getLimit());

        return appMapper.findAppAll(page);
    }

    @Override
    @Transactional
    public Integer addApp(Application app) {

        Integer appId=appMapper.addApp(app);

        log.info("打印插入的APPId--"+appId);

        Menu menu = new Menu();
        menu.setMenuTitle(app.getAppName());
        menu.setMenuHref("/version-page");
        menu.setPid(1);
//        menu.setMenuSpread(0);
        menu.setAppId(app.getAppId());
        Integer maxId = appMapper.findMaxMenuIdByPid(1);
        if(maxId!=null&&maxId>0){
            menu.setMenuId(maxId+1);
        }else{
            menu.setMenuId(101);
        }

        appMapper.addMenu(menu);

        return 1;
    }

    @Override
    @Transactional
    public Integer updateApp(Application app) {

        appMapper.updateApp(app);

        Menu menu = new Menu();
        menu.setAppId(app.getAppId());
        menu.setMenuTitle(app.getAppName());
        appMapper.updateMenu(menu);

        return 1;
    }

    @Override
    @Transactional
    public void deleteApp(String[] ids) {

        ArrayList<Integer> appIds = new ArrayList<>();
        for(String id:ids){
            appIds.add(Integer.parseInt(id));
        }
        List<Application> apps=appMapper.findAppName(appIds);

        appMapper.deleteMenu(appIds);

        appMapper.deleteApp(appIds);

        appMapper.deleteVersion(appIds);

        for (Application app:apps) {
            //清空文件夹
            File file = new File(gcFilePath+app.getAppName()+"-"+app.getAppId());
            FileHelps.deleteFile(file);
        }


    }


}
