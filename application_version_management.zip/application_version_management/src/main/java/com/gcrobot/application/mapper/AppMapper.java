package com.gcrobot.application.mapper;

import com.gcrobot.application.bean.Application;
import com.gcrobot.application.bean.Menu;
import com.gcrobot.application.util.PageHelp;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface AppMapper {
    /**
     * 分页查询所有的项目
     * */
    Integer findAppCount();
    List<Application> findAppAll(PageHelp page);

    /**
     * 插入app 获取app的Id
     * */
    Integer addApp(Application app);

    /**
     * 插入菜单
     * */
    void addMenu(Menu menu);
    /**
     * 查询一下 项目列表中最大的子选项id
     * */
    Integer findMaxMenuIdByPid(int pid);

    /**
     * 修改APP
     * */
    void updateApp(Application app);

    /**
     * 修改菜单
     * */
    void updateMenu(Menu menu);

    /**
     * 删除APP
     *
     * @param ids*/
    void deleteMenu(@Param("ids")List<Integer> ids);
    /**
     * 删除菜单
     *
     * @param ids*/
    void deleteApp(@Param("ids")List<Integer> ids);

    /**
     * 查询APP名称  删除文件夹用
     * */
    List<Application> findAppName(@Param("ids")List<Integer> appIds);

    /**
     * 删除app对应的所有版本
     * */
    void deleteVersion(@Param("ids")List<Integer> appIds);
}
