package com.gcrobot.application.controller;

import com.gcrobot.application.bean.Application;
import com.gcrobot.application.bean.Version;
import com.gcrobot.application.service.VersionService;
import com.gcrobot.application.util.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Slf4j
@RequestMapping("version")
@RestController
public class VersionController {

    @Value("${gc.file-path}")
    private String gcFilePath;

    @Value("${server.port}")
    private int serverPort;

    @Value("${gc.ip}")
    private String gcFilePathIp;

    @Value("${gc.ssl}")
    private boolean ssl;

    @Value("${server.servlet.context-path:}")
    private String projectName;

    @Autowired
    private VersionService versionService;


    @RequestMapping(value = "find-version")
    public ResultJson findVersion(@RequestParam Integer versionCode, @RequestParam Integer appId){
        Map<String,Object> map=new HashMap();

        try {
            if(!(versionCode!=null&&versionCode>0&&appId!=null&&appId>0)){
                return ResultJson.getInstance(105,"传入参数错误");
            }

            Version version = versionService.findVersion(appId);
            if(version==null){
                return ResultJson.getInstance(105,"版本库没有资源");
            }
            if(version.getVersionCode()==versionCode){
                map.put("newVersion",0);
            }else{
                map.put("versionId",version.getVersionId());
                map.put("appId",version.getAppId());
                map.put("versionCode",version.getVersionCode());
                map.put("versionName",version.getVersionName());
                map.put("versionDesc",version.getVersionDesc());
                if(ssl){
                    map.put("versionPath","https://"+ gcFilePathIp + projectName +"/file/"+version.getVersionPath());
                }else{
                    map.put("versionPath","http://"+ gcFilePathIp +":"+this.serverPort+ projectName +"/file/"+version.getVersionPath());
                }

                map.put("newVersion",1);
                map.put("versionVip",version.getVersionVip().equals("是")?1:0);
            }
        }catch (Exception e){
            e.printStackTrace();
            return ResultJson.getInstance(105,"莫名其妙的错误");
        }

        return ResultJson.getInstance(0,map);
    }

//不分页
//    @GetMapping(value = "data")
//    public LayuiDataGrid findVersionByMenuId(@RequestParam Integer menuId){
//        LayuiDataGrid layuiDataGrid = new LayuiDataGrid();
//        log.info("menuId"+menuId);
//
//        List<Version> data=versionService.findVersionByMenuId(menuId);
//        if(data!=null&&data.size()>0){
//            layuiDataGrid.setData(data);
//            layuiDataGrid.setCode(0);
//            layuiDataGrid.setCount(data.size());
//            layuiDataGrid.setMsg("加载数据完成");
//        }else{
//            layuiDataGrid.setCode(0);
//            layuiDataGrid.setCount(0);
//            layuiDataGrid.setMsg("当前还没有添加版本");
//            layuiDataGrid.setData(null);
//        }
//
//        return layuiDataGrid;
//    }

    @GetMapping(value="/info")
    public Map versionInfo(Integer menuId){
        log.info("/info");

        Application appByMenuId = versionService.findAppByMenuId(menuId);
        Map<String,Object> info=new HashMap<>();
        info.put("appName",appByMenuId.getAppName());
        info.put("appId",appByMenuId.getAppId());
        info.put("appDesc",appByMenuId.getAppDesc());

        Version version = versionService.findVersion(appByMenuId.getAppId());
        if(version!=null&&version.getVersionCode()>0){
            info.put("maxVersion",version.getVersionName());
            if(ssl){
                info.put("versionAddr","https://"+ gcFilePathIp + projectName +"/file/"+version.getVersionPath());
            }else{
                info.put("versionAddr","http://"+gcFilePathIp +":"+this.serverPort + projectName +"/file/"+version.getVersionPath());
            }


            info.put("versionDesc",version.getVersionDesc());
        }else{
            info.put("maxVersion","空");
            info.put("versionAddr","空");
            info.put("versionDesc","空");
        }

        return info;
    }


    @GetMapping(value = "data")
    public LayuiDataGrid findVersionByMenuId(PageHelp page, Integer menuId){
        LayuiDataGrid layuiDataGrid = new LayuiDataGrid();
        log.info("menuId"+menuId);

        if(page.getPage()<=0||page.getLimit()<=0) {
            layuiDataGrid.setCode(1);
            layuiDataGrid.setCount(0);
            layuiDataGrid.setData(null);
            layuiDataGrid.setMsg("请求格式错误");
            return layuiDataGrid;
        }

        Integer count=versionService.findVersionCount();

        List<Version> data=versionService.findVersionByMenuId(page,menuId);

        if(data!=null&&data.size()>0){
            layuiDataGrid.setData(data);
            layuiDataGrid.setCode(0);
            layuiDataGrid.setCount(count);
            layuiDataGrid.setMsg("加载数据完成");
        }else{
            layuiDataGrid.setCode(0);
            layuiDataGrid.setCount(0);
            layuiDataGrid.setMsg("当前还没有添加版本");
            layuiDataGrid.setData(null);
        }

        return layuiDataGrid;
    }


    @RequestMapping(value="upload")
    public ResultJson uploadVersion(MultipartFile file,Integer menuId) {
        ResultJson resultJson = new ResultJson();
        String fileName=file.getOriginalFilename();

//        Date date=new Date();
//        SimpleDateFormat formatter = new SimpleDateFormat("HHmmssSSS");
//        String formatStr =formatter.format(date);

        String uuid = UUID.randomUUID().toString().substring(0, 6);

        fileName=fileName.substring(0, fileName.indexOf("."))+"-"+uuid+fileName.substring(fileName.indexOf("."), fileName.length());

        resultJson.setObj(fileName);

        Application app=versionService.findAppByMenuId(menuId);

        String versionMkdir=gcFilePath+"/"+app.getAppId();

        FileHelps fileHelps = new FileHelps();
        File dir = new File(versionMkdir);

        if (fileHelps.isExist(versionMkdir)) {
            dir.mkdir();
        }

        File writeFile = new File(versionMkdir,fileName);

        try {

            file.transferTo(writeFile);

        } catch (IllegalStateException | IOException e) {
            e.printStackTrace();
            return  ResultJson.getInstance(102,"");
        }

        resultJson.setCode(0);
        resultJson.setObj(app.getAppId()+"/"+fileName);
        //session.setAttribute("fileName",fileName);

        return resultJson;
    }

    @RequestMapping(value="add")
    public ResultJson addVersion(Version version,Integer menuId){
        ResultJson resultJson=new ResultJson();

        if(version.getVersionCode()<=0 || versionService.findVersionCode(version.getVersionCode(),menuId)>0){
            return ResultJson.getInstance(103,"");
        }

        Integer count = versionService.saveVersion(version,menuId);
        if(count==1){
            resultJson.setCode(0);
            resultJson.setObj("新版本上传成功");
            return resultJson;
        }

        return ResultJson.getInstance(104,"");
    }

    @RequestMapping(value="update")
    public ResultJson updateVersion(Version version){

        Integer count=versionService.updateVersion(version);

        if(count==1){
            return ResultJson.getInstance(0,"修改完成");
        }

        return ResultJson.getInstance(105,"");
    }


    @RequestMapping(value="delete")
    public ResultJson deleteVersion(String ids){

        List<Version> versions=versionService.findVersionPath(ids);

        log.info(ids+"---"+versions.size());

        FileHelps fileHelps = new FileHelps();

        for(Version version:versions){
            fileHelps.deleteFile(gcFilePath+"/"+version.getVersionPath());
        }

        try{
            Integer count=versionService.deleteVersion(ids);
            return ResultJson.getInstance(0,"删除成功");
        }catch (Exception e){
            e.printStackTrace();
            return ResultJson.getInstance(105,"删除失败,联系管理员");
        }
    }
}
