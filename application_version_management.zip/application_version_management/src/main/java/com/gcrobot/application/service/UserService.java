package com.gcrobot.application.service;

import com.gcrobot.application.bean.Menu;
import com.gcrobot.application.bean.User;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface UserService {


    /**
     * 登录
     * */
    User findUserByUserName(String userName);

    /**
     * 查询菜单父节点
     * */
    List<Menu>  findAllParentMenu();
    /**
     * 查询菜单子节点
     * */
    List<Menu> findMenuByPid(Integer pid);

    /**
     * 修改密码
     * */
    void editPassword(Integer userId, String newPassword);
}
