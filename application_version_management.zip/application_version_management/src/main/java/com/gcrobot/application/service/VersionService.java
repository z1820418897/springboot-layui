package com.gcrobot.application.service;


import com.gcrobot.application.bean.Application;
import com.gcrobot.application.bean.Version;
import com.gcrobot.application.util.PageHelp;

import java.util.List;

public interface VersionService {
    Version findVersion(Integer appId);


    List<Version> findVersionByMenuId(Integer menuId);

    Integer findVersionCount();

    List<Version> findVersionByMenuId(PageHelp page,Integer menuId);

    Application findAppByMenuId(Integer menuId);

    Integer saveVersion(Version version, Integer menuId);

    Integer findVersionCode(Integer versionCode,Integer menuId);

    Integer updateVersion(Version version);

    List<Version> findVersionPath(String ids);

    Integer deleteVersion(String ids);
}
