package com.gcrobot.application.bean;

import lombok.Data;

@Data
public class Application {
    private Integer appId;
    private String appName;
    private String appDesc;
}
