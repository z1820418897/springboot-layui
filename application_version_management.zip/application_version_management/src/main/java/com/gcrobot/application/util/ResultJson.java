package com.gcrobot.application.util;

import lombok.Data;

import java.io.Serializable;

@Data
public class ResultJson implements Serializable {

    private int code;
    private Object obj;

    public static ResultJson getInstance(Integer code,Object obj){
        ResultJson resultJson=new ResultJson();
        resultJson.setCode(code);
        resultJson.setObj(obj);
        return resultJson;
    }

}
