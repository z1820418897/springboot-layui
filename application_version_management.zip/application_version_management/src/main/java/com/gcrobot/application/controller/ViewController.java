package com.gcrobot.application.controller;

import com.gcrobot.application.bean.Menu;
import com.gcrobot.application.bean.User;
import com.gcrobot.application.service.UserService;
import com.gcrobot.application.util.LayuiMenu;
import com.gcrobot.application.util.ResultJson;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Slf4j
@Controller
public class ViewController {

    @Autowired
    private UserService userService;


    @RequestMapping("/login")
    public String login(@RequestParam(value = "username",defaultValue = "") String username,
                        @RequestParam(value = "password",defaultValue = "") String password,
//                        @RequestParam(value = "remember",defaultValue = "") String remember,
                        Map<String,Object> map,HttpServletRequest request){


        if (!StringUtils.isEmpty(username) && !StringUtils.isEmpty(password)) {
            User user = userService.findUserByUserName(username);
            if(user==null){
                map.put("msg", "没有该账号");
                return "login";
            }

            if (username.equals(user.getUserName()) && password.equals(user.getPassWord())) {
                log.info(username+"账号或密码正确");
                request.getSession().setAttribute("gc-token",username);
                request.getSession().setAttribute("gc-user",user);
                return "redirect:/index-page";
            }
        }

        log.info(username+"账号或密码错误");
        map.put("msg", "账号或密码错误");

        return "login";

    }

    @RequestMapping("/menu")
    @ResponseBody
    public List menu(){

        List<LayuiMenu> data=new ArrayList<>();

        List<Menu> parentMenus=userService.findAllParentMenu();

        log.info(parentMenus.get(0).getMenuTitle());

        if(parentMenus!=null&&parentMenus.size()>0){

            for(Menu menu:parentMenus){

                ArrayList<LayuiMenu> layuiMenus = new ArrayList<>();

                List<Menu> menus=userService.findMenuByPid(menu.getMenuId());

                if(menus!=null&&menus.size()>0){
                    for(Menu m:menus){
                        LayuiMenu layuiMenu = m.formatLayuiMenu();
                        layuiMenus.add(layuiMenu);
                    }
                }

                LayuiMenu dataItem=menu.formatLayuiMenu();
                dataItem.setChildren(layuiMenus);

                data.add(dataItem);
            }
        }

        log.info(data.get(0).toString());

        return data;
    }


    @PostMapping("/editPassword")
    @ResponseBody
    public ResultJson editPassword(String oldPassword, String newPassword,HttpSession session){

        User user =(User)session.getAttribute("gc-user");
        if(user==null||!user.getPassWord().equals(oldPassword)) return ResultJson.getInstance(105,"原始密码错误");

        try {
            userService.editPassword(user.getUserId(),newPassword);
            return ResultJson.getInstance(0,"密码修改成功，下次登录时生效");
        }catch (Exception e){
            e.printStackTrace();
        }

        return ResultJson.getInstance(105,"密码修改失败");
    }



    @PostMapping("/logout")
    @ResponseBody
    public String logout(HttpSession session){
        session.invalidate();
        return "";
    }

}
