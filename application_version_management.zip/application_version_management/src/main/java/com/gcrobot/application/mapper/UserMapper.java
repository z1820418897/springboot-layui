package com.gcrobot.application.mapper;

import com.gcrobot.application.bean.Menu;
import com.gcrobot.application.bean.User;
import com.gcrobot.application.util.PageHelp;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface UserMapper {

    /**
     * 登录
     * */
    User findUserByUserName(String userName);

    /**
     * 查询菜单一级节点
     * */
    List<Menu>  findAllParentMenu();

    /**
     * 查询菜单子节点
     * */
    List<Menu> findMenuByPid(Integer pid);

    /**
     * 修改密码
     * */
    void editPassword(@Param("userId") Integer userId, @Param("newPassword")String newPassword);
}
