package com.gcrobot.application.bean;

import lombok.Data;

import java.io.Serializable;

@Data
public class Version implements Serializable {

    private Integer versionId;
    private Integer appId;
    private Integer versionCode;
    private String versionName;
    private String versionDesc;
    private String uploadTime;
    private String versionPath;
    private String versionVip;

    public void setVersionVip(Integer versionVip){
        this.versionVip=versionVip==0?"否":"是";
    }

}
