package com.gcrobot.application.controller;

import com.gcrobot.application.bean.Application;
import com.gcrobot.application.service.AppService;
import com.gcrobot.application.util.LayuiDataGrid;
import com.gcrobot.application.util.PageHelp;
import com.gcrobot.application.util.ResultJson;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RequestMapping("app")
@RestController
public class AppController {

    @Autowired
    private AppService appService;

    @RequestMapping("/data")
    public LayuiDataGrid data(PageHelp page){

        LayuiDataGrid layuiDataGrid = new LayuiDataGrid();
        if(page.getPage()<=0||page.getLimit()<=0) {
            layuiDataGrid.setCode(1);
            layuiDataGrid.setCount(0);
            layuiDataGrid.setData(null);
            layuiDataGrid.setMsg("请求格式错误");
            return layuiDataGrid;
        }
        Integer count=appService.findAppCount();
        List<Application> data=appService.findAppAll(page);
        if(data!=null&&data.size()>0){
            layuiDataGrid.setData(data);
            layuiDataGrid.setCode(0);
            layuiDataGrid.setCount(count);
            layuiDataGrid.setMsg("加载数据完成");
        }else{
            layuiDataGrid.setCode(0);
            layuiDataGrid.setCount(0);
            layuiDataGrid.setMsg("当前还没有添加版本");
            layuiDataGrid.setData(null);
        }

        return layuiDataGrid;
    }


    @PostMapping("/add")
    public ResultJson add(Application app){
        log.info("app-add"+app.toString());
        try {
            Integer success=appService.addApp(app);
            return ResultJson.getInstance(0,"添加成功");
        }catch (Exception e){
            e.printStackTrace();

        }
        return ResultJson.getInstance(105,"添加失败");
    }

    @PostMapping("/update")
    public ResultJson update(Application app){
        log.info("修改的信息"+app.toString());
        try {
            Integer success=appService.updateApp(app);
            return ResultJson.getInstance(0,"修改成功");
        }catch (Exception e){
            e.printStackTrace();
        }
        return ResultJson.getInstance(105,"修改失败");
    }

    @PostMapping("/delete")
    public ResultJson delete(String ids){
        try {
            appService.deleteApp(ids.split(","));
            return ResultJson.getInstance(0,"删除完成，确认刷新界面");
        }catch (Exception e){
            e.printStackTrace();
        }

        return ResultJson.getInstance(105,"删除失败");
    }

}
