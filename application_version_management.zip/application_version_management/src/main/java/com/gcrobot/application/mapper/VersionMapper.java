package com.gcrobot.application.mapper;

import com.gcrobot.application.bean.Application;
import com.gcrobot.application.bean.Version;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface VersionMapper {

    Version findVersion(Integer appId);

    List<Version> findVersionByMenuId(Integer menuId);

    Integer findVersionCount();

    List<Version> findVersionByMenuIdLimit(@Param("start")Integer start, @Param("end")Integer end, @Param("menuId")Integer menuId);

    Application findAppByMenuId(Integer menuId);

    Integer findVersionCode(@Param("versionCode")Integer versionCode,@Param("menuId")Integer menuId);

    Integer saveVersion(@Param("versionVip")Integer versionVip, @Param("version")Version version, @Param("menuId")Integer menuId);

    Integer updateVersion(@Param("versionVip")int versionVip, @Param("version")Version version);

    List<Version> findVersionPath(@Param("ids")List ids);

    Integer deleteVersion(@Param("ids")List ids);
}
