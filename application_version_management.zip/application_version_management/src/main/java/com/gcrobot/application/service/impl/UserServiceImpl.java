package com.gcrobot.application.service.impl;

import com.gcrobot.application.bean.Menu;
import com.gcrobot.application.bean.User;
import com.gcrobot.application.mapper.UserMapper;
import com.gcrobot.application.service.UserService;
import com.gcrobot.application.util.PageHelp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;


    @Override
    public User findUserByUserName(String userName) {
        return userMapper.findUserByUserName(userName);
    }

    @Override
    public List<Menu>  findAllParentMenu() {
        return userMapper.findAllParentMenu();
    }

    @Override
    public List<Menu> findMenuByPid(Integer pid) {

        return userMapper.findMenuByPid(pid);
    }

    @Override
    public void editPassword(Integer userId, String newPassword) {
        userMapper.editPassword(userId,newPassword);
    }


}
