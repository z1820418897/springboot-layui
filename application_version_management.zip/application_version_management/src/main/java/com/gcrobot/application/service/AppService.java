package com.gcrobot.application.service;

import com.gcrobot.application.bean.Application;
import com.gcrobot.application.util.PageHelp;

import java.util.List;

public interface AppService {

    /**
     * 分页查询
     * */
    Integer findAppCount();
    List<Application> findAppAll(PageHelp page);

    /**
     * 添加APP
     * */
    Integer addApp(Application app);

    /**
     * 更新App
     * */
    Integer updateApp(Application app);

    /**
     * 删除App
     * */
    void deleteApp(String[] ids);
}
