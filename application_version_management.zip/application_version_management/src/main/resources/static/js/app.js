layui.use([ 'upload', 'laydate', 'laypage', 'layer', 'table',
        'carousel', 'upload', 'element', 'slider' ],
    function() {
        var saveUrl;
        var uploadFileName=null;
        var addlayer;
        var $ = layui.jquery, upload = layui.upload, table = layui.table,
            element = layui.element, layer = layui.layer, slider = layui.slider, form = layui.form;


        //表单验证
        form.render();//这句一定要加，占坑
        form.verify({
            code:[/^$|^[0-9]{0,5}$/, '不符合要求'],
            codename: function (value){
                if(value.length > 10){
                    return '长度大于10！请重新输入';
                }
            },
            resc: function (value){
                if(value.length > 255){
                    return '描述长度不能超过255个字';
                }
            }
        });


        //加载表格
        table.render({
            elem : '#app',
            url : 'app/data',
            toolbar : '#toolbar-button',
            title : '数据表格',
            cols : [ [ {
                type : 'checkbox',
                fixed : 'left'
            }, {
                field : 'appId',
                title : '项目ID',
                fixed : 'left',
                unresize : true,
                sort : true
            }, {
                field : 'appName',
                title : '项目名称',
            }, {
                field : 'appDesc',
                title : '项目描述'
            } ] ],
            page : true
        });

        table
            .on(
                'toolbar(app)',
                function(obj) {
                    var checkStatus = table
                        .checkStatus(obj.config.id);

                    switch (obj.event) {
                        case 'refresh':
                            table.reload('app', {
                                url : 'app/data'
                            })
                            layer.msg('已刷新');

                            break;

                        case 'add':
                            saveUrl="app/add";

                            $(".update-save").removeAttr("disabled");
                            $(".update-save").removeClass('layui-disabled');

                            form.render();

                            var anim=Math.floor(Math.random()*6);

                            addlayer = layer.open({
                                id : 'add',
                                type : 1,
                                title : "上传新版本",
                                closeBtn : 1,
                                shade: 0.3,
                                anim : anim,
                                area : [ '70%' ],
                                resize : true,
                                content : $("#addApp"),
                                success : function(layer,index) {
                                },
                                end:function () {

                                    $("#edit-form")[0].reset();
                                    layui.form.render();

                                }
                            });

                            break;

                        case 'update':
                            var data = checkStatus.data;
                            if (data.length == 1) {

                                saveUrl="app/update";

                                $("#appDesc").val(data[0].appDesc);
                                $("#appId").val(data[0].appId);
                                $("#appName").val(data[0].appName);

                                form.render();

                                addlayer = layer.open({
                                    id : 'update',
                                    type : 1,
                                    title : "修改信息",
                                    closeBtn : 1,
                                    anim : 3,
                                    area : [ '70%','70%' ],
                                    resize : true,
                                    content : $("#addApp"),
                                    end:function () {
                                        $("#edit-form")[0].reset();
                                        layui.form.render();
                                    }
                                });


                            }else{
                                layer.msg('请勾选一条要修改的信息');
                            }

                            break;
                        case 'del':

                            var data = checkStatus.data;

                            if (data.length > 0) {
                                layer
                                    .confirm(
                                        '既然你删除了项目,那么项目对应的版本库也会被删除，确认删除吗？',
                                        function(
                                            index) {
                                            var ids = "";
                                            for (var i = 0; i < data.length; i++) {
                                                ids += data[i].appId
                                                    + ",";
                                            }

                                            $.ajax({
                                                url : 'app/delete',
                                                type : 'post',
                                                data : {
                                                    "ids" : ids
                                                },
                                                success : function(data) {
                                                    if(data.code==0){
                                                        alert(data.obj);
                                                        parent.location.reload();
                                                    }else{
                                                        layer.msg(data.obj+":"+data.code);
                                                    }
                                                }
                                            });
                                        });
                            } else {
                                layer.msg('请先选中行')
                            }

                            break;
                    }
                    ;
                });


        form.on('submit(save)', function(){

            var data=$("#edit-form").serialize();
            console.log(data);

            $.ajax({
                url:saveUrl,
                type:'post',
                data:data,
                success:function(data){
                    if(data.code==0){
                        alert(data.obj);
                        parent.location.reload();
                    }else{
                        layer.msg(data.obj+":"+data.code);
                    }

                }
            });

            return false;
        });

    })
