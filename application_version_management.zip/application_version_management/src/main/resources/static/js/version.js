


layui.use([ 'upload', 'laydate', 'laypage', 'layer', 'table',
        'carousel', 'upload', 'element', 'slider' ],
    function() {
        var saveUrl;
        var uploadFileName=null;
        var addindex;
        var menuId=self.frameElement.getAttribute('data-frameid');
        var $ = layui.jquery, upload = layui.upload, table = layui.table,
            element = layui.element, layer = layui.layer, slider = layui.slider, form = layui.form;

        function refresh(){
            table.reload('version', {
                url : 'version/data?menuId='+menuId
            })

            //显示表格上方卡片信息
            $.ajax({
                url:'version/info?menuId='+menuId,
                type:'get',
                success:function(data){
                    freshCrad(data);
                }
            });

        }

        function freshCrad(data){
            $("#card-appName").html(data.appName);
            $("#card-appId").html(data.appId);
            $("#card-appDesc").html(data.appDesc);
            $("#card-maxVersion").html(data.maxVersion);
            $("#card-versionAddr").html(data.versionAddr);
            if(data.versionAddr.toString()!="空"){
                $("#card-versionAddr").parent().attr("href",data.versionAddr);
            }else{
                $("#card-versionAddr").parent().removeAttr("href");
            }


            $("#card-versionDesc").html(data.versionDesc);
        }

        //表单验证
        form.render();//这句一定要加，占坑
        form.verify({
            code:[/^$|^[0-9]{0,5}$/, '不符合要求'],
            codename: function (value){
                if(value.length > 10){
                    return '长度大于10！请重新输入';
                }
            },
            resc: function (value){
                if(value.length > 255){
                    return '描述长度不能超过255个字';
                }
            }
        });

        //显示表格上方卡片信息
        $.ajax({
            url:'version/info?menuId='+menuId,
            type:'get',
            success:function(data){
                freshCrad(data);
            }
        });


        table.render({
            elem : '#version',
            url : 'version/data?menuId='+menuId,
            toolbar : '#toolbar-button',
            title : '数据表格',
            cols : [ [ {
                type : 'checkbox',
                fixed : 'left'
            }, {
                field : 'versionId',
                title : '版本ID',
                fixed : 'left',
                unresize : true,
                sort : true
            }, {
                field : 'versionCode',
                title : '版本标识',
                sort : true
            }, {
                field : 'versionName',
                title : '版本号',
                sort : true
            }, {
                field : 'uploadTime',
                title : '上传时间'
            }, {
                field : 'versionPath',
                title : '文件'
            }, {
                field : 'versionVip',
                title : '强制更新'
            },{
                field : 'versionDesc',
                title : '描述'
            } ] ],
            page : true
        });

        upload.render({
            elem : '#file',
            url : 'version/upload?menuId='+menuId,
            done : function(res) {
                if(res.code==0){
                    layer.msg('上传成功');
                    uploadFileName=res.obj;
                    $("#upload-msg").html(res.obj);
                }else{
                    layer.msg('上传失败');
                }
            },
            accept : 'file'
        });


        table
            .on(
                'toolbar(version)',
                function(obj) {
                    var checkStatus = table
                        .checkStatus(obj.config.id);

                    switch (obj.event) {
                        case 'refresh':
                            refresh();
                            layer.msg('已刷新');

                            break;

                        case 'add':

                            saveUrl="version/add";
                            $("#upload-file").show();
                            $("#upload-file-msg").show();

                            $(".update-save").removeAttr("disabled");
                            $(".update-save").removeClass('layui-disabled');

                            $('#versionVip-false').attr('checked',"");
                            $('#versionVip-true').removeAttr('checked');

                            form.render();

                            var anim=Math.floor(Math.random()*6);

                            addindex = layer.open({
                                id : 'add',
                                type : 1,
                                title : "上传新版本",
                                closeBtn : 1,
                                shade: 0.3,
                                anim : anim,
                                area : [ '70%' ],
                                resize : true,
                                content : $("#addVersion"),
                                success : function(layer,index) {
                                },
                                end:function () {
                                    $("#upload-msg").html("");
                                    uploadFileName=null;

                                    $("#edit-form")[0].reset();
                                    layui.form.render();
                                }
                            });

                            break;

                        case 'update':
                            uploadFileName="";
                            var data = checkStatus.data;
                            if (data.length == 1) {

                                saveUrl="version/update";
                                $("#upload-file").hide();
                                $("#upload-file-msg").hide();
                                $(".update-save").attr("disabled","disabled");
                                $(".update-save").addClass('layui-disabled');


                                $("#versionId").val(data[0].versionId);
                                $("#versionCode").val(data[0].versionCode);
                                $("#versionName").val(data[0].versionName);
                                $("#versionDesc").val(data[0].versionDesc);

                                if(data[0].versionVip.toString()=="否"){

                                    $('#versionVip-false').attr('checked',"");
                                    $('#versionVip-true').removeAttr('checked');

                                }else{
                                    $('#versionVip-true').attr('checked',"");
                                    $('#versionVip-false').removeAttr('checked');

                                }
                                form.render();

                                addindex = layer.open({
                                    id : 'update',
                                    type : 1,
                                    title : "修改信息",
                                    closeBtn : 1,
                                    anim : 3,
                                    area : [ '70%','70%' ],
                                    resize : true,
                                    content : $("#addVersion"),
                                    end:function () {
                                        $("#edit-form")[0].reset();
                                        layui.form.render();

                                        $("#upload-msg").html("");
                                        uploadFileName=null;
                                    }
                                });


                            }else{
                                layer.msg('请勾选一条要修改的信息');
                            }

                            break;
                        case 'del':

                            var data = checkStatus.data;

                            if (data.length > 0) {
                                layer
                                    .confirm(
                                        '真的删除行么',
                                        function(
                                            index) {
                                            var ids = "";
                                            for (var i = 0; i < data.length; i++) {
                                                ids += data[i].versionId
                                                    + ",";
                                            }

                                            $.ajax({
                                                url : 'version/delete',
                                                type : 'post',
                                                data : {
                                                    "ids" : ids
                                                },
                                                success : function(data) {
                                                    layer.close(index);
                                                    layer.msg(data.obj);
                                                    if(data.code==0){
                                                        refresh();
                                                    }
                                                }
                                            });
                                        });
                            } else {
                                layer.msg('请先选中行')
                            }

                            break;
                    }
                    ;
                });

        form.on('submit(save)', function(){

            if(uploadFileName==null){
                layer.msg("你还没有上传新版本,请上传后提交");
                return false;
            }
            var data=$("#edit-form").serialize()+"&menuId="+menuId+"&versionPath="+uploadFileName;

            console.log(data);

            $.ajax({
                url:saveUrl,
                type:'post',
                data:data,
                success:function(data){
                    if(data.code==0){
                        refresh();
                        layer.close(addindex);
                        layer.msg(data.obj);
                    }else{
                        layer.msg(data.obj+":"+data.code);
                    }

                }
            });

            return false;
        });

    })
