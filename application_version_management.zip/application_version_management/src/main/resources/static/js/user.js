layui.use(['form'], function(){
    var form = layui.form,$ = layui.jquery;

    //监听提交
    form.on('submit(formSubmit)',function(data){

        //layer.msg(JSON.stringify(data.field));

        if(data.field.newPassword!=data.field.newPassword2){
            layer.msg("两次新密码不一致");
            return false;
        }else{
            $.ajax(
                {
                    url:'editPassword',
                    type:'post',
                    data: {"oldPassword":data.field.oldPassword,"newPassword":data.field.newPassword},
                    success:function (msg) {
                        if(msg.code==0){
                            $("#password-from")[0].reset();
                            layui.form.render();
                        }
                        layer.alert(msg.obj);
                    },
                }
            )

        }
        // layer.msg(JSON.stringify(data.field));

        return false;
    });
});