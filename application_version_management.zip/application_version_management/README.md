# application_version_management （多项目版本库管理系统 -version 1.0）

测试使用nginx代理https连接成功，添加配置，可以修改项目的http和https切换下载地址，详情可查看application-dev.yml